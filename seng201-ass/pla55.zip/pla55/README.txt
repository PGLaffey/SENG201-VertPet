To Run Program:
- Open Terminal or CMD
- Use command "cd" to find the dirrectory the program jar files are in
- Use command "java -jar name_of_program.jar" to run the program
Jar files can be renamed without any issues arising in the program

JavaDoc:
The relevant JavaDocs are located in the doc folders inside the program source code folders.
EG vertpet/doc and vertpetguifresh/doc